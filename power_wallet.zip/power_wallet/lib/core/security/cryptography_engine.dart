import 'dart:convert';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:encrypt/encrypt.dart' as encrypt_pkg;

class CryptographyEngine {
  static const int pbkdf2Iterations = 100000;
  static const int keyLength = 32;

  Future<Uint8List> deriveKeyFromPin(String pin, Uint8List salt) async {
    final pbkdf2 = Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: pbkdf2Iterations,
      bits: keyLength * 8,
    );

    final secretKey = await pbkdf2.deriveKey(
      secretKey: SecretKey(utf8.encode(pin)),
      nonce: salt,
    );

    final keyBytes = await secretKey.extractBytes();
    return Uint8List.fromList(keyBytes);
  }

  Future<String> encryptData(String plainText, Uint8List key) async {
    final encryptionKey = encrypt_pkg.Key(key);
    final iv = encrypt_pkg.IV.fromSecureRandom(12);

    final encrypter = encrypt_pkg.Encrypter(
      encrypt_pkg.AES(encryptionKey, mode: encrypt_pkg.AESMode.gcm, padding: null),
    );

    final encrypted = encrypter.encrypt(plainText, iv: iv);
    
    final combined = Uint8List(iv.bytes.length + encrypted.bytes.length);
    combined.setRange(0, iv.bytes.length, iv.bytes);
    combined.setRange(iv.bytes.length, combined.length, encrypted.bytes);

    return base64.encode(combined);
  }

  Future<String> decryptData(String encryptedBase64, Uint8List key) async {
    try {
      final encryptionKey = encrypt_pkg.Key(key);
      final combinedBytes = base64.decode(encryptedBase64);

      final ivBytes = combinedBytes.sublist(0, 12);
      final cipherBytes = combinedBytes.sublist(12);

      final iv = encrypt_pkg.IV(ivBytes);
      final encrypter = encrypt_pkg.Encrypter(
        encrypt_pkg.AES(encryptionKey, mode: encrypt_pkg.AESMode.gcm, padding: null),
      );

      final decrypted = encrypter.decrypt(
        encrypt_pkg.Encrypted(cipherBytes),
        iv: iv,
      );
      return decrypted;
    } catch (e) {
      throw Exception('Decryption Failed. Incorrect key or corrupted payload: ${e.toString()}');
    }
  }
}