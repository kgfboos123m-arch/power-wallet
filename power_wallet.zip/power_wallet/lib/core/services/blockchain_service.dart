import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:web3dart/web3dart.dart';
import 'package:solana/solana.dart' as solana;
import 'package:http/http.dart' as http;

class BlockchainService {
  final Dio _dio;

  BlockchainService({Dio? dio}) : _dio = dio ?? Dio();

  // 1. Fetch EVM Balance (Ethereum, BNB Chain, Polygon)
  Future<double> getEVMBalance(String address, String rpcUrl) async {
    try {
      final httpClient = http.Client();
      final ethClient = Web3Client(rpcUrl, httpClient);
      
      final ethAddress = EthereumAddress.fromHex(address);
      final amount = await ethClient.getBalance(ethAddress);
      
      await ethClient.dispose();
      httpClient.close();
      
      return amount.getValueInUnit(EtherUnit.ether);
    } catch (e) {
      throw Exception('EVM Balance Fetch Error: ${e.toString()}');
    }
  }

  // 2. Fetch Solana Balance
  Future<double> getSolanaBalance(String address, String rpcUrl) async {
    try {
      final rpcClient = solana.RpcClient(rpcUrl);
      final balanceResponse = await rpcClient.getBalance(address);
      
      // 1 SOL = 10^9 Lamports
      return balanceResponse.value / 1000000000;
    } catch (e) {
      throw Exception('Solana Balance Fetch Error: ${e.toString()}');
    }
  }

  // 3. Fetch Bitcoin Balance (Native SegWit)
  Future<double> getBitcoinBalance(String address) async {
    try {
      final response = await _dio.get('https://blockstream.info/api/address/$address');
      if (response.statusCode == 200 && response.data != null) {
        final stats = response.data['chain_stats'];
        final funded = (stats['funded_txo_sum'] as num).toDouble();
        final spent = (stats['spent_txo_sum'] as num).toDouble();
        
        // 1 BTC = 10^8 Satoshi
        return (funded - spent) / 100000000.0;
      }
      throw Exception('Invalid response from Bitcoin indexer');
    } catch (e) {
      throw Exception('Bitcoin Balance Fetch Error: ${e.toString()}');
    }
  }

  // 4. Fetch TRON Balance (TRX)
  Future<double> getTronBalance(String address, String rpcUrl) async {
    try {
      final url = '$rpcUrl/wallet/getaccount';
      final response = await _dio.post(
        url,
        data: jsonEncode({'address': address, 'visible': true}),
        options: Options(headers: {'Content-Type': 'application/json'}),
      );

      if (response.statusCode == 200 && response.data != null) {
        final data = response.data;
        if (data.isEmpty || data['balance'] == null) {
          return 0.0; // New TRON account balance is 0 TRX
        }
        final balanceInSun = (data['balance'] as num).toDouble();
        // 1 TRX = 10^6 Sun
        return balanceInSun / 1000000.0;
      }
      throw Exception('Invalid response from TRON RPC');
    } catch (e) {
      throw Exception('TRON Balance Fetch Error: ${e.toString()}');
    }
  }
}