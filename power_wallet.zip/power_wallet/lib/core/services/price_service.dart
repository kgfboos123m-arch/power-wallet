import '../network/api_client.dart';

class CoinPrice {
  final double usdPrice;
  final double change24h;

  CoinPrice({required this.usdPrice, required this.change24h});
}

class PriceService {
  final ApiClient _apiClient;

  PriceService(this._apiClient);

  Future<Map<String, CoinPrice>> getSimplePrices(List<String> coinIds) async {
    final idsParam = coinIds.join(',');
    final response = await _apiClient.get(
      '/simple/price',
      queryParameters: {
        'ids': idsParam,
        'vs_currencies': 'usd',
        'include_24hr_change': 'true',
      },
    );

    if (response.statusCode == 200 && response.data != null) {
      final Map<String, dynamic> data = response.data;
      final Map<String, CoinPrice> prices = {};

      data.forEach((key, value) {
        final usd = (value['usd'] as num).toDouble();
        final change = (value['usd_24h_change'] as num?)?.toDouble() ?? 0.0;
        prices[key] = CoinPrice(usdPrice: usd, change24h: change);
      });

      return prices;
    } else {
      throw Exception('Failed to fetch simple prices');
    }
  }

  Future<List<double>> getMarketChart(String coinId, {int days = 1}) async {
    final response = await _apiClient.get(
      '/coins/$coinId/market_chart',
      queryParameters: {
        'vs_currency': 'usd',
        'days': days.toString(),
      },
    );

    if (response.statusCode == 200 && response.data != null) {
      final List<dynamic> prices = response.data['prices'];
      return prices.map((item) => (item[1] as num).toDouble()).toList();
    } else {
      throw Exception('Failed to fetch market chart for $coinId');
    }
  }
}