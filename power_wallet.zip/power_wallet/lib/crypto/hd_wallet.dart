import 'dart:typed_data';
import 'package:bip39/bip39.dart' as bip39;
import 'package:hex/hex.dart';
import 'package:ed25519_hd_key/ed25519_hd_key.dart';
import 'package:web3dart/credentials.dart';
import 'package:web3dart/crypto.dart';
import 'package:bitcoin_flutter/bitcoin_flutter.dart' as btc_flutter;
import 'package:solana/solana.dart' as solana;
import 'package:crypto/crypto.dart' as dart_crypto;

class GeneratedWalletResult {
  final String mnemonic;
  final String rootSeedHex;

  GeneratedWalletResult({required this.mnemonic, required this.rootSeedHex});
}

class ChainKeys {
  final String privateKey;
  final String publicKey;
  final String address;

  ChainKeys({
    required this.privateKey,
    required this.publicKey,
    required this.address,
  });
}

class Base58 {
  static const String _alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

  static String encode(Uint8List bytes) {
    if (bytes.isEmpty) return '';

    int zeros = 0;
    while (zeros < bytes.length && bytes[zeros] == 0) {
      zeros++;
    }

    BigInt intVal = BigInt.zero;
    for (int i = 0; i < bytes.length; i++) {
      intVal = (intVal << 8) + BigInt.from(bytes[i]);
    }

    String result = '';
    while (intVal > BigInt.zero) {
      final BigInt remainder = intVal % BigInt.from(58);
      intVal = intVal ~/ BigInt.from(58);
      result = _alphabet[remainder.toInt()] + result;
    }

    for (int i = 0; i < zeros; i++) {
      result = _alphabet[0] + result;
    }

    return result;
  }

  static String encodeCheck(Uint8List bytes) {
    final hash1 = dart_crypto.sha256.convert(bytes).bytes;
    final hash2 = dart_crypto.sha256.convert(hash1).bytes;
    
    final checksum = hash2.sublist(0, 4);
    
    final combined = Uint8List(bytes.length + 4);
    combined.setRange(0, bytes.length, bytes);
    combined.setRange(bytes.length, combined.length, checksum);
    
    return encode(combined);
  }
}

class HDWalletEngine {
  GeneratedWalletResult createNewWallet() {
    final mnemonic = bip39.generateMnemonic();
    final seed = bip39.mnemonicToSeed(mnemonic);
    return GeneratedWalletResult(
      mnemonic: mnemonic,
      rootSeedHex: HEX.encode(seed),
    );
  }

  GeneratedWalletResult importWallet(String mnemonic) {
    final cleanMnemonic = mnemonic.trim().toLowerCase();
    if (!bip39.validateMnemonic(cleanMnemonic)) {
      throw Exception('Invalid Mnemonic Phrase provided.');
    }
    final seed = bip39.mnemonicToSeed(cleanMnemonic);
    return GeneratedWalletResult(
      mnemonic: cleanMnemonic,
      rootSeedHex: HEX.encode(seed),
    );
  }

  ChainKeys deriveEVMChainKeys(String rootSeedHex, {int index = 0}) {
    final seedBytes = HEX.decode(rootSeedHex);
    final ethWallet = EthPrivateKey.fromHex(HEX.encode(
      _deriveEthereumKeyBytes(seedBytes, index)
    ));

    return ChainKeys(
      privateKey: HEX.encode(ethWallet.privateKey),
      publicKey: HEX.encode(ethWallet.encodedPublicKey),
      address: ethWallet.address.hexEip55,
    );
  }

  ChainKeys deriveBNBChainKeys(String rootSeedHex, {int index = 0}) {
    return deriveEVMChainKeys(rootSeedHex, index: index);
  }

  ChainKeys derivePolygonKeys(String rootSeedHex, {int index = 0}) {
    return deriveEVMChainKeys(rootSeedHex, index: index);
  }

  Future<ChainKeys> deriveSolanaKeys(String rootSeedHex, {int index = 0}) async {
    final seedBytes = Uint8List.fromList(HEX.decode(rootSeedHex));
    final path = "m/44'/501'/$index'/0'";
    
    final derivedData = await ED25519_HD_KEY.derivePath(path, seedBytes);
    final keypair = await solana.Ed25519HDKeyPair.fromSeedWithHdPath(
      seed: seedBytes,
      hdPath: solana.HdPath.parse(path),
    );

    return ChainKeys(
      privateKey: HEX.encode(derivedData.key),
      publicKey: keypair.address,
      address: keypair.address,
    );
  }

  ChainKeys deriveBitcoinKeys(String rootSeedHex, {int index = 0}) {
    final seedBytes = Uint8List.fromList(HEX.decode(rootSeedHex));
    final hdWallet = btc_flutter.HDWallet.fromSeed(seedBytes);
    final child = hdWallet.derivePath("m/84'/0'/0'/0/$index");
    
    if (child.privateKey == null || child.publicKey == null) {
      throw Exception('Bitcoin Key Derivation Failed.');
    }

    return ChainKeys(
      privateKey: HEX.encode(child.privateKey!),
      publicKey: HEX.encode(child.publicKey!),
      address: child.address ?? '',
    );
  }

  ChainKeys deriveTronKeys(String rootSeedHex, {int index = 0}) {
    final seedBytes = Uint8List.fromList(HEX.decode(rootSeedHex));
    final hdWallet = btc_flutter.HDWallet.fromSeed(seedBytes);
    final child = hdWallet.derivePath("m/44'/195'/0'/0/$index");
    
    if (child.privateKey == null) {
      throw Exception('TRON Key Derivation Failed.');
    }

    final privateKeyBytes = child.privateKey!;
    final ethPrivateKey = EthPrivateKey(privateKeyBytes);
    final uncompressedPubKey = ethPrivateKey.encodedPublicKey;

    final hash = keccak256(uncompressedPubKey);
    final rawAddress = hash.sublist(12);

    final tronAddressBytes = Uint8List(21);
    tronAddressBytes[0] = 0x41;
    tronAddressBytes.setRange(1, 21, rawAddress);

    final address = Base58.encodeCheck(tronAddressBytes);

    return ChainKeys(
      privateKey: HEX.encode(privateKeyBytes),
      publicKey: HEX.encode(ethPrivateKey.encodedPublicKey),
      address: address,
    );
  }

  Uint8List _deriveEthereumKeyBytes(List<int> rootSeed, int index) {
    return Uint8List.fromList(rootSeed.sublist(index * 4, (index * 4) + 32));
  }
}