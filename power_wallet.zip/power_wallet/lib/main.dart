import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'app/config/theme.dart';
import 'app/config/di_setup.dart';
import 'features/auth/presentation/screens/welcome_screen.dart';
import 'features/dashboard/presentation/bloc/wallet_cubit.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Global Service Locator
  setupLocator();
  
  runApp(const PowerWalletApp());
}

class PowerWalletApp extends StatelessWidget {
  const PowerWalletApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => WalletCubit()..loadWalletData(),
      child: MaterialApp(
        title: 'Power Wallet',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.dark,
        home: const WelcomeScreen(),
      ),
    );
  }
}