import 'package:flutter/material.dart';
import '../widgets/settings_tile.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _biometricsEnabled = true;
  bool _autoLockEnabled = true;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Settings',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: isDark ? Colors.white : Colors.black87,
          ),
        ),
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        children: [
          _buildSectionHeader('Wallets & Security', isDark),
          SettingsTile(
            title: 'Active Wallet',
            subtitle: 'Power Wallet 1 (Multi-Chain)',
            icon: Icons.account_balance_wallet_rounded,
            iconColor: Theme.of(context).primaryColor,
            onTap: () {},
          ),
          const Divider(height: 1, thickness: 0.5, color: Colors.white10),
          SettingsTile(
            title: 'Show Recovery Phrase',
            subtitle: 'Secure backup of your 12-word seed',
            icon: Icons.vpn_key_rounded,
            iconColor: Colors.amber,
            onTap: () {},
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('Preferences', isDark),
          SettingsTile(
            title: 'Biometric Lock',
            subtitle: 'Unlock with FaceID or Fingerprint',
            icon: Icons.fingerprint_rounded,
            iconColor: Colors.green,
            trailing: Switch.adaptive(
              value: _biometricsEnabled,
              activeColor: Theme.of(context).primaryColor,
              onChanged: (val) {
                setState(() {
                  _biometricsEnabled = val;
                });
              },
            ),
            onTap: () {},
          ),
          const Divider(height: 1, thickness: 0.5, color: Colors.white10),
          SettingsTile(
            title: 'Auto-Lock Screen',
            subtitle: 'Lock screen after 30s of inactivity',
            icon: Icons.lock_outline_rounded,
            iconColor: Colors.redAccent,
            trailing: Switch.adaptive(
              value: _autoLockEnabled,
              activeColor: Theme.of(context).primaryColor,
              onChanged: (val) {
                setState(() {
                  _autoLockEnabled = val;
                });
              },
            ),
            onTap: () {},
          ),
          const Divider(height: 1, thickness: 0.5, color: Colors.white10),
          SettingsTile(
            title: 'Primary Currency',
            subtitle: 'USD (\$)',
            icon: Icons.monetization_on_outlined,
            iconColor: Colors.teal,
            onTap: () {},
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('About & Support', isDark),
          SettingsTile(
            title: 'Join Our Community',
            subtitle: 'Follow updates on Telegram & X',
            icon: Icons.groups_rounded,
            iconColor: Colors.blueAccent,
            onTap: () {},
          ),
          const Divider(height: 1, thickness: 0.5, color: Colors.white10),
          SettingsTile(
            title: 'App Version',
            subtitle: 'v1.0.0 (Build 1)',
            icon: Icons.info_outline_rounded,
            iconColor: Colors.grey,
            trailing: const SizedBox.shrink(),
            onTap: () {},
          ),
          const SizedBox(height: 100),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title, bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.2,
          color: isDark ? Colors.white38 : Colors.black38,
        ),
      ),
    );
  }
}