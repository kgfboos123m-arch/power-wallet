import 'package:flutter/material.dart';
import '../widgets/swap_asset_input.dart';
import '../widgets/slippage_settings_sheet.dart';

class SwapScreen extends StatefulWidget {
  const SwapScreen({super.key});

  @override
  State<SwapScreen> createState() => _SwapScreenState();
}

class _SwapScreenState extends State<SwapScreen> {
  final TextEditingController _fromController = TextEditingController();
  final TextEditingController _toController = TextEditingController();

  String _fromSymbol = 'ETH';
  String _toSymbol = 'USDT';
  String _fromBalance = '1.24 ETH';
  String _toBalance = '342.10 USDT';

  double _fromFiat = 0.00;
  double _toFiat = 0.00;
  double _slippage = 0.5;

  @override
  void dispose() {
    _fromController.dispose();
    _toController.dispose();
    super.dispose();
  }

  void _onFromAmountChanged(String val) {
    final amount = double.tryParse(val) ?? 0.0;
    setState(() {
      _fromFiat = amount * 2400.0;
      _toController.text = (amount * 2400.0).toStringAsFixed(2);
      _toFiat = amount * 2400.0;
    });
  }

  void _onToAmountChanged(String val) {
    final amount = double.tryParse(val) ?? 0.0;
    setState(() {
      _toFiat = amount;
      _fromController.text = (amount / 2400.0).toStringAsFixed(4);
      _fromFiat = amount;
    });
  }

  void _switchAssets() {
    setState(() {
      final tempSymbol = _fromSymbol;
      _fromSymbol = _toSymbol;
      _toSymbol = tempSymbol;

      final tempBalance = _fromBalance;
      _fromBalance = _toBalance;
      _toBalance = tempBalance;

      final tempAmount = _fromController.text;
      _fromController.text = _toController.text;
      _toController.text = tempAmount;

      final tempFiat = _fromFiat;
      _fromFiat = _toFiat;
      _toFiat = tempFiat;
    });
  }

  void _showSlippageSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return SlippageSettingsSheet(
          initialSlippage: _slippage,
          onSlippageChanged: (val) {
            setState(() {
              _slippage = val;
            });
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Swap',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: isDark ? Colors.white : Colors.black87,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.tune_rounded),
            onPressed: _showSlippageSheet,
          ),
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            children: [
              const SizedBox(height: 12),
              SwapAssetInput(
                title: 'From',
                symbol: _fromSymbol,
                balance: _fromBalance,
                fiatValue: _fromFiat,
                controller: _fromController,
                onAssetSelect: () {},
                onChanged: _onFromAmountChanged,
              ),
              const SizedBox(height: 8),
              Stack(
                alignment: Alignment.center,
                children: [
                  Divider(
                    color: isDark ? Colors.white10 : Colors.black10,
                    thickness: 1,
                  ),
                  GestureDetector(
                    onTap: _switchAssets,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Theme.of(context).primaryColor,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Theme.of(context).primaryColor.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.swap_vert_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              SwapAssetInput(
                title: 'To',
                symbol: _toSymbol,
                balance: _toBalance,
                fiatValue: _toFiat,
                controller: _toController,
                onAssetSelect: () {},
                onChanged: _onToAmountChanged,
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: isDark ? Colors.white.withOpacity(0.02) : Colors.black.withOpacity(0.02),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: isDark ? Colors.white.withOpacity(0.05) : Colors.black.withOpacity(0.05),
                    width: 1,
                  ),
                ),
                child: Column(
                  children: [
                    _buildDetailRow(
                      'Provider Route',
                      'Power Multi-DEX (1inch API)',
                      isDark,
                    ),
                    const SizedBox(height: 10),
                    _buildDetailRow(
                      'Slippage Tolerance',
                      '$_slippage%',
                      isDark,
                      valueColor: Theme.of(context).primaryColor,
                    ),
                    const SizedBox(height: 10),
                    _buildDetailRow(
                      'Estimated Network Fee',
                      '~\$1.50 (0.0006 ETH)',
                      isDark,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).primaryColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    'Confirm Swap',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, bool isDark, {Color? valueColor}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 13,
            color: isDark ? Colors.white38 : Colors.black38,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.bold,
            color: valueColor ?? (isDark ? Colors.white70 : Colors.black70),
          ),
        ),
      ],
    );
  }
}