import 'package:flutter/material.dart';

class SlippageSettingsSheet extends StatefulWidget {
  final double initialSlippage;
  final Function(double) onSlippageChanged;

  const SlippageSettingsSheet({
    super.key,
    required this.initialSlippage,
    required this.onSlippageChanged,
  });

  @override
  State<SlippageSettingsSheet> createState() => _SlippageSettingsSheetState();
}

class _SlippageSettingsSheetState extends State<SlippageSettingsSheet> {
  late double _selectedSlippage;
  final TextEditingController _customController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _selectedSlippage = widget.initialSlippage;
    if (![0.1, 0.5, 1.0].contains(_selectedSlippage)) {
      _customController.text = _selectedSlippage.toString();
    }
  }

  @override
  void dispose() {
    _customController.dispose();
    super.dispose();
  }

  void _selectSlippage(double val) {
    setState(() {
      _selectedSlippage = val;
      _customController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: EdgeInsets.only(
        top: 16,
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF151A33) : Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Slippage Tolerance',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: isDark ? Colors.white : Colors.black87,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Slippage tolerance is the maximum price change you are willing to accept during a swap.',
            style: TextStyle(
              fontSize: 12,
              color: isDark ? Colors.white54 : Colors.black54,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              _buildPresetButton(0.1),
              const SizedBox(width: 8),
              _buildPresetButton(0.5),
              const SizedBox(width: 8),
              _buildPresetButton(1.0),
              const SizedBox(width: 8),
              Expanded(
                child: SizedBox(
                  height: 44,
                  child: TextField(
                    controller: _customController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    textAlign: TextAlign.center,
                    onChanged: (val) {
                      final parsed = double.tryParse(val);
                      if (parsed != null) {
                        setState(() {
                          _selectedSlippage = parsed;
                        });
                      }
                    },
                    decoration: InputDecoration(
                      hintText: 'Custom',
                      contentPadding: EdgeInsets.zero,
                      hintStyle: const TextStyle(fontSize: 13),
                      suffixText: '%',
                      suffixStyle: TextStyle(
                        color: isDark ? Colors.white54 : Colors.black54,
                        fontSize: 13,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: _customController.text.isNotEmpty
                              ? Theme.of(context).primaryColor
                              : Colors.grey.withOpacity(0.3),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Theme.of(context).primaryColor,
                          width: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: () {
                widget.onSlippageChanged(_selectedSlippage);
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).primaryColor,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'Apply Settings',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPresetButton(double val) {
    final isSelected = _selectedSlippage == val && _customController.text.isEmpty;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return SizedBox(
      height: 44,
      width: 64,
      child: OutlinedButton(
        onPressed: () => _selectSlippage(val),
        style: OutlinedButton.styleFrom(
          backgroundColor: isSelected
              ? Theme.of(context).primaryColor
              : Colors.transparent,
          foregroundColor: isSelected
              ? Colors.white
              : (isDark ? Colors.white70 : Colors.black87),
          side: BorderSide(
            color: isSelected
                ? Theme.of(context).primaryColor
                : Colors.grey.withOpacity(0.3),
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          padding: EdgeInsets.zero,
        ),
        child: Text(
          '$val%',
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}