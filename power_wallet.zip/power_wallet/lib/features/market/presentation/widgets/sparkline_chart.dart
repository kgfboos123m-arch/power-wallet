import 'package:flutter/material.dart';

class SparklineChart extends StatelessWidget {
  final List<double> data;
  final bool isPositive;

  const SparklineChart({
    super.key,
    required this.data,
    required this.isPositive,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 70,
      height: 35,
      child: CustomPaint(
        painter: _SparklinePainter(data, isPositive),
      ),
    );
  }
}

class _SparklinePainter extends CustomPainter {
  final List<double> data;
  final bool isPositive;

  _SparklinePainter(this.data, this.isPositive);

  @override
  void paint(Canvas canvas, Size size) {
    if (data.isEmpty) return;

    final paint = Paint()
      ..color = isPositive ? Colors.green : Colors.red
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round;

    final path = Path();
    final double minVal = data.reduce((a, b) => a < b ? a : b);
    final double maxVal = data.reduce((a, b) => a > b ? a : b);
    final double valRange = maxVal - minVal == 0 ? 1 : maxVal - minVal;

    final double widthStep = size.width / (data.length - 1);

    for (int i = 0; i < data.length; i++) {
      final double x = i * widthStep;
      final double normalizedY = (data[i] - minVal) / valRange;
      final double y = size.height - (normalizedY * size.height);

      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}