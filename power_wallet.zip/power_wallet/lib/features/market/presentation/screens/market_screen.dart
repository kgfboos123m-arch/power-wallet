import 'package:flutter/material.dart';
import '../widgets/market_coin_item.dart';

class MarketScreen extends StatefulWidget {
  const MarketScreen({super.key});

  @override
  State<MarketScreen> createState() => _MarketScreenState();
}

class _MarketScreenState extends State<MarketScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Markets',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: isDark ? Colors.white : Colors.black87,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search_rounded),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.star_border_rounded),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: isDark ? Colors.white.withOpacity(0.05) : Colors.black.withOpacity(0.03),
                borderRadius: BorderRadius.circular(12),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                labelColor: Colors.white,
                unselectedLabelColor: isDark ? Colors.white38 : Colors.black38,
                dividerColor: Colors.transparent,
                tabs: const [
                  Tab(text: 'All'),
                  Tab(text: 'Trending'),
                  Tab(text: 'Watchlist'),
                ],
              ),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildCoinList(),
                _buildCoinList(),
                _buildCoinList(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCoinList() {
    return ListView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      children: const [
        MarketCoinItem(
          name: 'Bitcoin',
          symbol: 'BTC',
          price: '\$61,500.00',
          change: '2.45%',
          isPositive: true,
          trendData: [60100, 60500, 60300, 60800, 61200, 61500],
          iconColor: Colors.orange,
        ),
        Divider(height: 1, thickness: 0.5, color: Colors.white10),
        MarketCoinItem(
          name: 'Ethereum',
          symbol: 'ETH',
          price: '\$2,400.00',
          change: '1.85%',
          isPositive: false,
          trendData: [2550, 2520, 2480, 2490, 2430, 2400],
          iconColor: Colors.deepPurpleAccent,
                ),
        Divider(height: 1, thickness: 0.5, color: Colors.white10),
        MarketCoinItem(
          name: 'Solana',
          symbol: 'SOL',
          price: '\$150.00',
          change: '8.34%',
          isPositive: true,
          trendData: [135, 138, 142, 140, 145, 150],
          iconColor: Colors.purple,
        ),
        Divider(height: 1, thickness: 0.5, color: Colors.white10),
        MarketCoinItem(
          name: 'BNB Chain',
          symbol: 'BNB',
          price: '\$600.00',
          change: '0.12%',
          isPositive: true,
          trendData: [598, 599, 597, 601, 600, 600],
          iconColor: Colors.yellow,
        ),
        Divider(height: 1, thickness: 0.5, color: Colors.white10),
        MarketCoinItem(
          name: 'TRON',
          symbol: 'TRX',
          price: '\$0.13',
          change: '4.20%',
          isPositive: false,
          trendData: [0.14, 0.138, 0.135, 0.132, 0.131, 0.13],
          iconColor: Colors.redAccent,
        ),
        SizedBox(height: 100),
      ],
    );
  }
}