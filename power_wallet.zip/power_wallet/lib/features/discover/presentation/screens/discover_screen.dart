import 'package:flutter/material.dart';
import '../widgets/staking_item.dart';
import '../widgets/dapp_category_item.dart';

class DiscoverScreen extends StatelessWidget {
  const DiscoverScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Discover',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: isDark ? Colors.white : Colors.black87,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search_rounded),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Staking Stargate',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: isDark ? Colors.white : Colors.black87,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 110,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  children: const [
                    StakingItem(
                      name: 'Solana',
                      symbol: 'SOL',
                      apy: '6.50%',
                      iconColor: Colors.purple,
                    ),
                    SizedBox(width: 12),
                    StakingItem(
                      name: 'Ethereum',
                      symbol: 'ETH',
                      apy: '3.80%',
                      iconColor: Colors.deepPurpleAccent,
                    ),
                    SizedBox(width: 12),
                    StakingItem(
                      name: 'TRON',
                      symbol: 'TRX',
                      apy: '4.15%',
                      iconColor: Colors.redAccent,
                    ),
                    SizedBox(width: 12),
                    StakingItem(
                      name: 'BNB Chain',
                      symbol: 'BNB',
                      apy: '2.90%',
                      iconColor: Colors.yellow,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'DeFi Platforms',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : Colors.black87,
                    ),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: const Text('See All'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const DappCategoryItem(
                title: 'Uniswap V3',
                description: 'Multi-chain decentralized protocol & AMM.',
                icon: Icons.swap_calls_rounded,
                iconBgColor: Colors.pinkAccent,
              ),
              const Divider(height: 1, thickness: 0.5, color: Colors.white10),
              const DappCategoryItem(
                title: 'PancakeSwap',
                description: 'Leading decentralized exchange on BNB Chain.',
                icon: Icons.layers_rounded,
                iconBgColor: Colors.orange,
              ),
              const Divider(height: 1, thickness: 0.5, color: Colors.white10),
              const DappCategoryItem(
                title: 'Aave V3',
                description: 'Non-custodial liquidity protocol to earn interest.',
                icon: Icons.savings_rounded,
                iconBgColor: Colors.teal,
              ),
              const SizedBox(height: 28),
              Text(
                'Smart Contract Utilities',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: isDark ? Colors.white : Colors.black87,
                ),
              ),
              const SizedBox(height: 12),
              const DappCategoryItem(
                title: 'OpenSea',
                description: 'Browse, buy, and sell digital NFT assets.',
                icon: Icons.grid_view_rounded,
                iconBgColor: Colors.blueAccent,
              ),
              const Divider(height: 1, thickness: 0.5, color: Colors.white10),
              const DappCategoryItem(
                title: 'Lido Staking',
                description: 'Liquid staking protocol for Ethereum.',
                icon: Icons.opacity_rounded,
                iconBgColor: Colors.cyan,
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
    );
  }
}