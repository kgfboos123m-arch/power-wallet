import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../dashboard/presentation/bloc/wallet_cubit.dart';

class MnemonicVerifyScreen extends StatefulWidget {
  final List<String> mnemonicWords;

  const MnemonicVerifyScreen({super.key, required this.mnemonicWords});

  @override
  State<MnemonicVerifyScreen> createState() => _MnemonicVerifyScreenState();
}

class _MnemonicVerifyScreenState extends State<MnemonicVerifyScreen> {
  late List<String> _shuffledWords;
  final List<String> _selectedWords = [];

  @override
  void initState() {
    super.initState();
    _shuffledWords = List.from(widget.mnemonicWords)..shuffle();
  }

  void _onWordSelected(String word) {
    setState(() {
      _selectedWords.add(word);
      _shuffledWords.remove(word);
    });
  }

  void _onWordDeselected(String word) {
    setState(() {
      _shuffledWords.add(word);
      _selectedWords.remove(word);
    });
  }

  bool _isVerificationSuccess() {
    if (_selectedWords.length != widget.mnemonicWords.length) return false;
    for (int i = 0; i < widget.mnemonicWords.length; i++) {
      if (_selectedWords[i] != widget.mnemonicWords[i]) return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isFull = _selectedWords.length == widget.mnemonicWords.length;
    final isSuccess = isFull && _isVerificationSuccess();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('Verify Backup'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Confirm recovery phrase',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Select the words in the correct order to complete the backup verification.',
                    style: TextStyle(
                      fontSize: 13,
                      color: isDark ? Colors.white54 : Colors.black54,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Container(
                    width: double.infinity,
                    minHeight: 120,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0xFF151A33) : const Color(0xFFF5F7FB),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isFull 
                            ? (isSuccess ? Colors.green : Colors.red)
                            : (isDark ? Colors.white10 : Colors.black10),
                      ),
                    ),
                    child: _selectedWords.isEmpty
                        ? Center(
                            child: Text(
                              'Selected words will appear here.',
                              style: TextStyle(
                                fontSize: 13,
                                color: isDark ? Colors.white24 : Colors.black24,
                              ),
                            ),
                          )
                        : Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _selectedWords.map((word) {
                              return GestureDetector(
                                onTap: () => _onWordDeselected(word),
                                child: Chip(
                                  label: Text(word),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                  ),
                  const SizedBox(height: 24),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    alignment: WrapAlignment.center,
                    children: _shuffledWords.map((word) {
                      return GestureDetector(
                        onTap: () => _onWordSelected(word),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          decoration: BoxDecoration(
                            color: isDark ? Colors.white.withOpacity(0.05) : Colors.black.withOpacity(0.04),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isDark ? Colors.white10 : Colors.black10,
                            ),
                          ),
                          child: Text(
                            word,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: isDark ? Colors.white : Colors.black87,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
              BlocConsumer<WalletCubit, WalletState>(
                listener: (context, state) {
                  if (state is WalletLoaded) {
                    Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
                  } else if (state is WalletError) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(state.message)),
                    );
                  }
                },
                builder: (context, state) {
                  final isLoading = state is WalletLoading;

                  return SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton(
                      onPressed: isSuccess && !isLoading
                          ? () {
                              final rawMnemonic = widget.mnemonicWords.join(' ');
                              context.read<WalletCubit>().importWallet(rawMnemonic);
                            }
                          : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Theme.of(context).primaryColor,
                        foregroundColor: Colors.white,
                        disabledBackgroundColor: Colors.grey.withOpacity(0.12),
                        disabledForegroundColor: Colors.grey,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 0,
                      ),
                      child: isLoading
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                color: Colors.white,
                              ),
                            )
                          : const Text(
                              'Complete Backup',
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}