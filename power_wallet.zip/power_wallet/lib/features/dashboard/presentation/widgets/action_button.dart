import 'package:flutter/material.dart';

class WalletActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const WalletActionButton({
    super.key,
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: isDark 
                  ? Colors.white.withOpacity(0.06) 
                  : Theme.of(context).primaryColor.withOpacity(0.08),
              shape: BoxShape.circle,
              border: Border.all(
                color: isDark 
                    ? Colors.white.withOpacity(0.08) 
                    : Theme.of(context).primaryColor.withOpacity(0.12),
                width: 1,
              ),
            ),
            child: Icon(
              icon,
              color: Theme.of(context).primaryColor,
              size: 24,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: isDark ? Colors.white70 : Colors.black80,
            ),
          ),
        ],
      ),
    );
  }
}