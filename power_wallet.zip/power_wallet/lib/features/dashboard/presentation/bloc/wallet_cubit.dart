import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../app/config/di_setup.dart';
import '../../../../core/security/secure_storage_handler.dart';
import '../../../../core/services/blockchain_service.dart';
import '../../../../core/services/price_service.dart';
import '../../../../crypto/hd_wallet.dart';

class AccountDetails {
  final String chainName;
  final String symbol;
  final String address;
  final double balance;
  final double priceUsd;
  final double change24h;

  AccountDetails({
    required this.chainName,
    required this.symbol,
    required this.address,
    required this.balance,
    required this.priceUsd,
    required this.change24h,
  });

  double get fiatValue => balance * priceUsd;
}

abstract class WalletState {}

class WalletInitial extends WalletState {}

class WalletLoading extends WalletState {}

class WalletLoaded extends WalletState {
  final String mnemonic;
  final List<AccountDetails> accounts;
  final double totalPortfolioValue;
  final double totalChangePercentage;

  WalletLoaded({
    required this.mnemonic,
    required this.accounts,
    required this.totalPortfolioValue,
    required this.totalChangePercentage,
  });
}

class WalletError extends WalletState {
  final String message;
  WalletError(this.message);
}

class WalletCubit extends Cubit<WalletState> {
  final SecureStorageRepository _storage = locator<SecureStorageRepository>();
  final HDWalletEngine _walletEngine = locator<HDWalletEngine>();
  final PriceService _priceService = locator<PriceService>();
  final BlockchainService _blockchainService = locator<BlockchainService>();

  WalletCubit() : super(WalletInitial());

  Future<void> createWallet() async {
    emit(WalletLoading());
    try {
      final generated = _walletEngine.createNewWallet();
      
      await _storage.write('mnemonic', generated.mnemonic);
      await _storage.write('rootSeedHex', generated.rootSeedHex);
      
      await loadWalletData();
    } catch (e) {
      emit(WalletError('Failed to create wallet: ${e.toString()}'));
    }
  }

  Future<void> importWallet(String mnemonic) async {
    emit(WalletLoading());
    try {
      final restored = _walletEngine.importWallet(mnemonic);
      
      await _storage.write('mnemonic', restored.mnemonic);
      await _storage.write('rootSeedHex', restored.rootSeedHex);
      
      await loadWalletData();
    } catch (e) {
      emit(WalletError('Failed to import wallet: ${e.toString()}'));
    }
  }

  Future<void> loadWalletData() async {
    try {
      final mnemonic = await _storage.read('mnemonic');
      final rootSeedHex = await _storage.read('rootSeedHex');

      if (mnemonic == null || rootSeedHex == null) {
        emit(WalletInitial());
        return;
      }

      emit(WalletLoading());

      final ethKeys = _walletEngine.deriveEVMChainKeys(rootSeedHex);
      final solKeys = await _walletEngine.deriveSolanaKeys(rootSeedHex);
      final btcKeys = _walletEngine.deriveBitcoinKeys(rootSeedHex);
      final trxKeys = _walletEngine.deriveTronKeys(rootSeedHex);

      final prices = await _priceService.getSimplePrices([
        'bitcoin',
        'ethereum',
        'solana',
        'binancecoin',
        'tron',
      ]);

      final btcBalance = await _blockchainService.getBitcoinBalance(btcKeys.address);
      final ethBalance = await _blockchainService.getEVMBalance(ethKeys.address, 'https://rpc.ankr.com/eth');
      final solBalance = await _blockchainService.getSolanaBalance(solKeys.address, 'https://api.mainnet-beta.solana.com');
      final bnbBalance = await _blockchainService.getEVMBalance(ethKeys.address, 'https://binance.llamarpc.com');
      final trxBalance = await _blockchainService.getTronBalance(trxKeys.address, 'https://api.trongrid.io');

      final List<AccountDetails> accounts = [
        AccountDetails(
          chainName: 'Bitcoin',
          symbol: 'BTC',
          address: btcKeys.address,
          balance: btcBalance,
          priceUsd: prices['bitcoin']?.usdPrice ?? 61500.0,
          change24h: prices['bitcoin']?.change24h ?? 0.0,
        ),
        AccountDetails(
          chainName: 'Ethereum',
          symbol: 'ETH',
          address: ethKeys.address,
          balance: ethBalance,
          priceUsd: prices['ethereum']?.usdPrice ?? 2400.0,
          change24h: prices['ethereum']?.change24h ?? 0.0,
        ),
        AccountDetails(
          chainName: 'Solana',
          symbol: 'SOL',
          address: solKeys.address,
          balance: solBalance,
          priceUsd: prices['solana']?.usdPrice ?? 150.0,
          change24h: prices['solana']?.change24h ?? 0.0,
        ),
        AccountDetails(
          chainName: 'BNB Chain',
          symbol: 'BNB',
          address: ethKeys.address,
          balance: bnbBalance,
          priceUsd: prices['binancecoin']?.usdPrice ?? 600.0,
          change24h: prices['binancecoin']?.change24h ?? 0.0,
        ),
        AccountDetails(
          chainName: 'TRON',
          symbol: 'TRX',
          address: trxKeys.address,
          balance: trxBalance,
          priceUsd: prices['tron']?.usdPrice ?? 0.13,
          change24h: prices['tron']?.change24h ?? 0.0,
        ),
      ];

      double totalValue = 0.0;
      double weightedChangeSum = 0.0;

      for (var acc in accounts) {
        totalValue += acc.fiatValue;
        weightedChangeSum += (acc.fiatValue * acc.change24h);
      }

      double totalChange = totalValue > 0 ? (weightedChangeSum / totalValue) : 0.0;

      emit(WalletLoaded(
        mnemonic: mnemonic,
        accounts: accounts,
        totalPortfolioValue: totalValue,
        totalChangePercentage: totalChange,
      ));
    } catch (e) {
      emit(WalletError('Failed to load wallet data: ${e.toString()}'));
    }
  }

  Future<void> wipeWallet() async {
    emit(WalletLoading());
    try {
      await _storage.clearAll();
      emit(WalletInitial());
    } catch (e) {
      emit(WalletError('Failed to wipe wallet: ${e.toString()}'));
    }
  }
}