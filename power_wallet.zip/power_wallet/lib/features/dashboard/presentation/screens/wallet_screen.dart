import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../widgets/glass_balance_card.dart';
import '../widgets/action_button.dart';
import '../widgets/token_list_item.dart';
import '../bloc/wallet_cubit.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: Theme.of(context).primaryColor.withOpacity(0.2),
              child: Icon(Icons.person, color: Theme.of(context).primaryColor, size: 20),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Power Wallet 1',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white : Colors.black87,
                  ),
                ),
                Text(
                  'Multi-Chain Active',
                  style: TextStyle(fontSize: 11, color: isDark ? Colors.white38 : Colors.black38),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code_scanner_rounded),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.notifications_none_rounded),
            onPressed: () {},
          ),
        ],
      ),
      body: BlocBuilder<WalletCubit, WalletState>(
        builder: (context, state) {
          if (state is WalletLoading) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (state is WalletLoaded) {
            final fiatStr = '\$${state.totalPortfolioValue.toStringAsFixed(2)}';
            final changeStr = '${state.totalChangePercentage.toStringAsFixed(2)}%';
            final isPositive = state.totalChangePercentage >= 0;

            return RefreshIndicator(
              onRefresh: () => context.read<WalletCubit>().loadWalletData(),
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(
                  parent: BouncingScrollPhysics(),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 12),
                      GlassBalanceCard(
                        totalBalance: fiatStr,
                        percentageChange: changeStr,
                        isPositive: isPositive,
                      ),
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          WalletActionButton(
                            icon: Icons.arrow_upward_rounded,
                            label: 'Send',
                            onTap: () {},
                          ),
                          WalletActionButton(
                            icon: Icons.arrow_downward_rounded,
                            label: 'Receive',
                            onTap: () {},
                          ),
                          WalletActionButton(
                            icon: Icons.add_card_rounded,
                            label: 'Buy',
                            onTap: () {},
                          ),
                          WalletActionButton(
                            icon: Icons.swap_calls_rounded,
                            label: 'Swap',
                            onTap: () {},
                          ),
                        ],
                      ),
                      const SizedBox(height: 28),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Assets',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: isDark ? Colors.white : Colors.black87,
                            ),
                          ),
                          TextButton(
                            onPressed: () {},
                            child: const Text('Manage Tokens'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      ListView.separated(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: state.accounts.length,
                        separatorBuilder: (context, index) => const Divider(
                          height: 1,
                          thickness: 0.5,
                          color: Colors.white10,
                        ),
                        itemBuilder: (context, index) {
                          final acc = state.accounts[index];
                          Color iconColor = Colors.orange;
                          if (acc.symbol == 'ETH') iconColor = Colors.deepPurpleAccent;
                          if (acc.symbol == 'SOL') iconColor = Colors.purple;
                          if (acc.symbol == 'BNB') iconColor = Colors.yellow;
                          if (acc.symbol == 'TRX') iconColor = Colors.redAccent;

                          return TokenListItem(
                            name: acc.chainName,
                            symbol: acc.symbol,
                            balance: '${acc.balance.toStringAsFixed(4)} ${acc.symbol}',
                            fiatValue: '\$${acc.fiatValue.toStringAsFixed(2)}',
                            price: '\$${acc.priceUsd.toStringAsFixed(2)}',
                            changePercentage: '${acc.change24h.toStringAsFixed(2)}%',
                            isPositiveChange: acc.change24h >= 0,
                            iconColor: iconColor,
                          );
                        },
                      ),
                      const SizedBox(height: 100),
                    ],
                  ),
                ),
              ),
            );
          }

          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.account_balance_wallet_outlined, size: 64, color: Colors.grey),
                const SizedBox(height: 16),
                const Text('No Active Wallet found.'),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () => context.read<WalletCubit>().loadWalletData(),
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}