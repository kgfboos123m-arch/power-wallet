import 'package:get_it/get_it.dart';
import '../../core/network/api_client.dart';
import '../../core/security/cryptography_engine.dart';
import '../../core/security/secure_storage_handler.dart';
import '../../core/services/blockchain_service.dart';
import '../../core/services/price_service.dart';
import '../../crypto/hd_wallet.dart';

final GetIt locator = GetIt.instance;

void setupLocator() {
  locator.registerLazySingleton<SecureStorageRepository>(() => SecureStorageHandler());
  locator.registerLazySingleton<CryptographyEngine>(() => CryptographyEngine());
  locator.registerLazySingleton<HDWalletEngine>(() => HDWalletEngine());
  
  final apiClient = ApiClient();
  locator.registerLazySingleton<ApiClient>(() => apiClient);
  locator.registerLazySingleton<PriceService>(() => PriceService(apiClient));
  
  locator.registerLazySingleton<BlockchainService>(() => BlockchainService());
}